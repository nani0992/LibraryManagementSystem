public class Main {
    public static void main(String[] args) {
        Library library = new Library();

        Book book1 = new Book("B101", "1984", "George Orwell");
        Book book2 = new Book("B102", "To Kill a Mockingbird", "Harper Lee");

        User user1 = new User("U001", "Alice");

        library.addBook(book1);
        library.addBook(book2);
        library.addUser(user1);

        library.listBooks();
        library.issueBook("B101");
        library.returnBook("B101");
        library.listBooks();
    }
}