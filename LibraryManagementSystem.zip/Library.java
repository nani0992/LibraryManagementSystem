import java.util.*;

public class Library {
    private List<Book> books;
    private List<User> users;

    public Library() {
        books = new ArrayList<>();
        users = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void addUser(User user) {
        users.add(user);
    }

    public void issueBook(String bookId) {
        for (Book book : books) {
            if (book.getBookId().equals(bookId)) {
                book.issueBook();
                return;
            }
        }
        System.out.println("Book not found.");
    }

    public void returnBook(String bookId) {
        for (Book book : books) {
            if (book.getBookId().equals(bookId)) {
                book.returnBook();
                return;
            }
        }
        System.out.println("Book not found.");
    }

    public void listBooks() {
        for (Book book : books) {
            System.out.println(book.getBookId() + " - " + book.getTitle() + " by " + book.getAuthor() + " | Issued: " + book.isIssued());
        }
    }
}