# Library Management System (OOP in Java)

## Description
This is a simple console-based Library Management System developed using Object-Oriented Programming in Java.

## Features
- Add and list books
- Add users
- Issue and return books

## Technologies
- Java
- VS Code

## How to Run
1. Compile all `.java` files
2. Run the `Main.java` file using terminal:
   ```
   javac *.java
   java Main
   ```

## Author
Your Name